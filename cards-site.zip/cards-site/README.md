# Cards Site - Decap CMS + GitHub Pages

Minimal test site with admin panel for adding cards.

## Quick Setup

1. **Create a new GitHub repo** and push these files to it

2. **Enable GitHub Pages**  
   Settings → Pages → Source: Deploy from branch → `main` / `root`

3. **Update the CMS config**  
   Edit `admin/config.yml` and change:
   ```yaml
   repo: YOUR_USERNAME/YOUR_REPO
   ```
   to your actual repo path (e.g., `mtlacy216/card-test`)

4. **Visit your site**
   - Main site: `https://YOUR_USERNAME.github.io/YOUR_REPO/`
   - Admin panel: `https://YOUR_USERNAME.github.io/YOUR_REPO/admin/`

## How It Works

- `/admin` loads Decap CMS which authenticates via GitHub OAuth
- When you save changes, Decap commits directly to your repo
- GitHub Pages rebuilds automatically (takes ~30 seconds)

## OAuth Note

This config uses a free public OAuth proxy (`decap-oauth.netlify.app`). For production, consider:
- Hosting on Netlify instead (built-in identity)
- Running your own OAuth app
- Using [Sveltia CMS](https://github.com/sveltia/sveltia-cms) which has built-in GitHub auth

## Local Development

```bash
# Install Jekyll
gem install bundler jekyll

# Run locally
bundle exec jekyll serve

# For CMS local testing, in another terminal:
npx decap-server
```

Then add `local_backend: true` to `admin/config.yml`.

## File Structure

```
├── _config.yml          # Jekyll config
├── _data/
│   └── cards.yml        # Card data (edited by CMS)
├── admin/
│   ├── index.html       # CMS interface
│   └── config.yml       # CMS configuration
├── index.html           # Main page template
└── README.md
```
